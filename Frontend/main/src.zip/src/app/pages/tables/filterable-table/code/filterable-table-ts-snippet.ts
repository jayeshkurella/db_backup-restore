export const FILTERABLE_TABLE_TS_SNIPPET = `  import { Component, OnInit } from '@angular/core';
    import { MatTableDataSource, MatTableModule } from '@angular/material/table';
    import { CommonModule } from '@angular/common';
    import { MatCardModule } from '@angular/material/card';
    import { MatFormFieldModule } from '@angular/material/form-field';
    import { MatInputModule } from '@angular/material/input';
    import { MatDividerModule } from '@angular/material/divider';


    export interface productsData {
      id: number;
      imagePath: string;
      uname: string;
      position: string;
      productName: string;
      budget: number;
      priority: string;
    }

    const ELEMENT_DATA: productsData[] = [
      {
        id: 1,
        imagePath: 'assets/images/profile/user-1.jpg',
        uname: 'Sunil Joshi',
        position: 'Web Designer',
        productName: 'Elite Admin',
        budget: 3.9,
        priority: 'low',
      },
      {
        id: 2,
        imagePath: 'assets/images/profile/user-2.jpg',
        uname: 'Andrew McDownland',
        position: 'Project Manager',
        productName: 'Real Homes Theme',
        budget: 24.5,
        priority: 'medium',
      },
      {
        id: 3,
        imagePath: 'assets/images/profile/user-3.jpg',
        uname: 'Christopher Jamil',
        position: 'Project Manager',
        productName: 'MedicalPro Theme',
        budget: 12.8,
        priority: 'high',
      },
      {
        id: 4,
        imagePath: 'assets/images/profile/user-4.jpg',
        uname: 'Nirav Joshi',
        position: 'Frontend Engineer',
        productName: 'Hosting Press HTML',
        budget: 2.4,
        priority: 'critical',
      },
    ];

    /**
     * @title expand table */
     */
    @Component({
    selector: 'app-expand-table',
      selector: 'app-filterable-table',
        imports: [
          MatTableModule,
          MatCardModule,
          MatFormFieldModule,
          CommonModule,
          MatInputModule,
          MatDividerModule,
          Highlight,
          HighlightAuto,
          HighlightLineNumbers,
          AppCodeViewComponent,
        ],
        templateUrl: './filterable-table.component.html',
    })
    export class AppFilterableTableComponent {

      displayedColumns: string[] = ['assigned', 'name', 'priority', 'budget'];
        dataSource = new MatTableDataSource(ELEMENT_DATA);
      
        applyFilter(event: Event) {
          const filterValue = (event.target as HTMLInputElement).value;
          this.dataSource.filter = filterValue.trim().toLowerCase();
        }

    }
`;