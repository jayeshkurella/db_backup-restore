export const LINE_CHART_HTML_SNIPPET = `  <apx-chart [series]="lineChartOptions.series" [chart]="lineChartOptions.chart" [xaxis]="lineChartOptions.xaxis"
      [yaxis]="lineChartOptions.yaxis" [grid]="lineChartOptions.grid" [stroke]="lineChartOptions.stroke"
      [tooltip]="lineChartOptions.tooltip" [dataLabels]="lineChartOptions.dataLabels" [legend]="lineChartOptions.legend"
      [colors]="lineChartOptions.colors" [markers]="lineChartOptions.markers">
    </apx-chart>
`;