export const GREDIENT_CHART_HTML_SNIPPET = `  <apx-chart [series]="gredientChartOptions.series" [chart]="gredientChartOptions.chart"
      [stroke]="gredientChartOptions.stroke" [xaxis]="gredientChartOptions.xaxis" [fill]="gredientChartOptions.fill"
      [markers]="gredientChartOptions.markers" [yaxis]="gredientChartOptions.yaxis"
      [plotOptions]="gredientChartOptions.plotOptions" [tooltip]="gredientChartOptions.tooltip"
      [grid]="gredientChartOptions.grid">
    </apx-chart>
`;