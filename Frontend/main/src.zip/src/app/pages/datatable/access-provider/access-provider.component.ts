import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'app-access-provider',
  imports: [],
  templateUrl: './access-provider.component.html',
  styleUrl: './access-provider.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AccessProviderComponent { }
