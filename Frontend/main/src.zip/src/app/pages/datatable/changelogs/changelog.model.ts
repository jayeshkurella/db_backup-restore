export interface DailyChangeLog {
    id?: number;
    date: string; 
    version: string; 
    added: string[];
    modified: string[];
    tested: string[];
   
  }
  
  