import { SafeTitlecasePipe } from './safe-titlecase.pipe';

describe('SafeTitlecasePipe', () => {
  it('create an instance', () => {
    const pipe = new SafeTitlecasePipe();
    expect(pipe).toBeTruthy();
  });
});
