import { Component } from '@angular/core';
import { MaterialModule } from '../../../material.module';

@Component({
  selector: 'app-selling-product',
  imports: [MaterialModule],
  templateUrl: './selling-product.component.html',
})
export class AppSellingProductComponent {}
