
from .models.additonal_info import *
from .models.address import *
from .models.admin_user import *
from .models.consent import *
from .models.contact import *
from .models.document import *
from .models.fir import *
from .models.hospital import *
from .models.last_known_details import *
from .models.match import *
from .models.person_user import *
from .models.person import *
from .models.police_station import *
from .models.user import *
from .models.volunteer import *
from .models.dummy_table import dummy_Table