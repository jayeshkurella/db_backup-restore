from .person_admin import *
from .address_admin import *
from .contact_admin import *
from .additional_info_admin import  *
from .last_seen_details_admin import  *
from .fir_admin import *
from .police_station_admin import *
from .document_admin import *
from .admin_user_admin import *
from .consent_admin import *
from .hospital_admin import *
from .person_user_admin import *
from .match_user import  *
from .person_admin import *
from .user_admin import *
from .volunteer_admin import *

