from django.contrib import admin

from ..models import PersonUser

admin.site.register(PersonUser)