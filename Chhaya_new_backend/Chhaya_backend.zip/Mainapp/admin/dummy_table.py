from ..models import dummy_Table
from django.contrib import admin

admin.site.register(dummy_Table)