from ..models import PoliceStation
from django.contrib import admin
admin.site.register(PoliceStation)