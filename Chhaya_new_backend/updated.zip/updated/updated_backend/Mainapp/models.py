
from .Models.additonal_info import *
from .Models.address import *
from .Models.admin_user import *
from .Models.consent import *
from .Models.contact import *
from .Models.document import *
from .Models.fir import *
from .Models.hospital import *
from .Models.last_known_details import *
from .Models.match import *
from .Models.person_user import *
from .Models.person import *
from .Models.police_station import *
from .Models.user import *
